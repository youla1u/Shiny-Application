
library(ggplot2)

server <- function(input, output, session) {
  info = reactive({
    inFile<-input$file1
    if(is.null(inFile))
      return(NULL)
    f<-read.csv(inFile$datapath, header=input$header, sep=input$sep,dec = ",")
    vars <- names(f)
    updateSelectInput(session,"columns","Select Columns", choices = vars)
    f
  })
  
  output$myplot <- renderPlot({
    pll<-input$pl
    f <- info()
    f<- subset(f, select = input$columns)
    
    if(ncol(f)==1){
      f <- as.matrix(f)
      fil<-input$fil
      if (pll=="density"){
        Title<-input$title3
        c<-colnames(f)
        ggplot() + aes(f)+ geom_density(binwidth=1, colour="black",fill=fil)+
                 labs(title=Title,x=c)
      }
      else if (pll=="histogram"){
        Title<-input$title4
        fil2<-input$fil2
        c<-colnames(f)
        ggplot() + aes(f)+ geom_histogram(binwidth=1, colour="black",fill=fil2,stat = "count")+
                 labs(title=Title,x=c)
      }
      else if ((pll=="boxplot") & (is.numeric(f)!=FALSE)){
        Title<-input$title5
        c<-colnames(f)
        ggplot() + aes(x="",y=f)+ geom_boxplot(binwidth=1, colour="black",fill="blue")+
                 labs(title=Title,x="",y=c)
        
      }
    }
    

    else if((ncol(f)==2)){
      if(pll=="scarterplot_bivarate"){
        m<-input$method1
        Title<-input$title1
        clor<-input$color
        eps<-input$Epesseur
        c<-as.vector(colnames(f))
        a<-c[1]
        b<-c[2]
        if((is.numeric(f[,1])!=FALSE) &(is.numeric(f[,2])!=FALSE)){
          ggplot(f,aes(f[,1],f[,2]))+geom_point(size=eps,color=clor)+geom_smooth(method =m)+
            labs(title=Title,x=a,y=b)
      }
      }
    }
    
    
    else if((ncol(f)==3) & (pll=="scarterplot_multivarate")){
      Title<-input$title2
      m<-input$method2
      f<-as.data.frame(f)
      c<-as.vector(colnames(f))
      a<-c[1]
      b<-c[2]
      if((is.numeric(f[,1])!=FALSE) &(is.numeric(f[,2])!=FALSE)){
        facet<-input$facet.grid
        if((is.numeric(f[,3])==FALSE) & (facet=="No")){
          ggplot(f,aes(f[,1],f[,2],colour=f[,3])) + geom_point()+ geom_smooth(method = m)+
          labs(title=Title,x=a,y=b)
        }
        else if((is.numeric(f[,3])==FALSE) & (facet=="Yes")){
          ggplot(f,aes(f[,1],f[,2])) + geom_point(aes(colour = factor(f[,3]), shape = factor(f[,3])))+ 
                  geom_smooth(method = m)+labs(title=Title,x=a,y=b)+facet_grid(cols = vars(f[,3]))
        }
      }
    }
    else if((ncol(f)==4) & (pll=="scarterplot_multivarate")){
      Title<-input$title2
      m<-input$method2
      f<-as.data.frame(f)
      c<-as.vector(colnames(f))
      a<-c[1]
      b<-c[2]
      if((is.numeric(f[,1])!=FALSE) &(is.numeric(f[,2])!=FALSE)){
        facet<-input$facet.grid
        if((is.numeric(f[,3])==FALSE) & (facet=="No")){
          ggplot(f,aes(f[,1],f[,2],colour=f[,3])) + geom_point(aes(colour = factor(f[,3]), 
            shape =factor(f[,4])))+ geom_smooth(method = m)+labs(title=Title,x=a,y=b)
        }
        else if((is.numeric(f[,3])==FALSE) & (facet=="Yes")){
          ggplot(f,aes(f[,1],f[,2])) + geom_point(aes(colour = factor(f[,3]), shape = factor(f[,4])))+ 
            geom_smooth(method = m)+labs(title=Title,x=a,y=b)+facet_grid(cols = vars(f[,3]))
        }
      }
    }   
    

  })
  
  output$table_display <- renderTable({
    f <- info()
    f <- subset(f, select = input$columns) 
    head(f)
  })
  output$data_summary <- renderTable({
    f <- info()
    f <- subset(f, select = input$columns) 
    summary(f)
  })
  
}


