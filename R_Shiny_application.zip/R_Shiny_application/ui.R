library(shiny)
library(shinydashboard)
library(MASS)
ui <-dashboardPage(skin = "yellow",
                   dashboardHeader(title = "Data Vizualisation"),
                   dashboardSidebar(
                     dataTableOutput('mytable'),
                     
                     fileInput('file1', 'Select csv or txt file',
                               accept=c('text/csv')
                     ),
                     checkboxInput('header', 'Header', TRUE),
                     radioButtons('sep', 'Separator',
                                  c(Tab='\t',Comma=',', Semicolon=';')
                     ),
                     
                     actionButton("choice", "incorporate external information"),
                     
                     selectInput("columns", "Select Columns", choices = NULL,multiple =TRUE),
                     selectInput("pl", "Specific Plot_Type", choices =c("histogram","density",
                                "scarterplot_bivarate","scarterplot_multivarate","boxplot")),
                    
                     
                     conditionalPanel(condition="input.pl=='scarterplot_bivarate'",
                                      textInput("method1","Plot smooth","lm"),
                                      textInput("color","Points Color","red"),
                                      sliderInput("Epesseur","Size of poits",value =1.5,min = 1.0,max=5.0,step=0.25 ),
                                      textInput("title1","Plot Titlte","TITLE")
                                      ),
                     conditionalPanel(condition="input.pl=='scarterplot_multivarate'",
                                      textInput("method2"," Plot smooth","lm"),
                                      selectInput("facet.grid", "Facet_Grid", choices =c("No","Yes")),
                                      textInput("title2","Plot Titlte","TITLE")
                                    
                                     ),
                     conditionalPanel(condition="input.pl=='density'",
                                      textInput("fil","Density Color","blue"),
                                      textInput("title3","Plot Titlte","TITLE")
                                      
                     ),
                     conditionalPanel(condition="input.pl=='histogram'",
                                      textInput("fil2","Histogram Color","blue"),
                                      textInput("title4","Plot Titlte","TITLE")
  
                     ),
                     conditionalPanel(condition="input.pl=='boxplot'",
                                      textInput("title5","Plot Titlte","TITLE")
                                      )
                   ),
                   dashboardBody(
                     fluidPage(
                       box (plotOutput("myplot")),
                       box(title = "DATA Head",tableOutput("table_display"),background = 'black'),
                       box(title = "DATA Summary",tableOutput("data_summary"),background = 'black')
          
                     )
                   )
                   
)